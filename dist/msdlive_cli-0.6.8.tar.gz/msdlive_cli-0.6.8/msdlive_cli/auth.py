import json
from pathlib import Path
import requests
import jwt
from rich import print
from rich.console import Console
import typer
import getpass
from datetime import datetime, timedelta

from .lib import get_app_path, handle_request_errors
from .config import auth_url
from .flags import flags
from .errors import ExitError

# Amount of time the refresh token is valid for
REFRESH_LIFE_SPAN = timedelta(days=2)
# Time before refresh token expires when user should reauthenticate
BUFFER_TIME = timedelta(days=1)


class AlreadyLoggedIn(Exception):
    pass


class NotAuthenticated(Exception):
    pass


def get_app_state_file_path():
    return get_app_path() / "auth-tokens.json"


def reset_permissions(file_path: Path):
    # Used to lock down a file so that only the current user can read/write to it
    permissions = 0o600
    file_path.chmod(permissions)


def read_app_state():
    auth_tokens_path = get_app_state_file_path()
    if flags["debug"]:
        print(f"reading tokens from auth_tokens_path: {auth_tokens_path}")
    data = {}
    try:
        with auth_tokens_path.open(encoding="UTF-8") as app_state_file:
            data = json.load(app_state_file)
        reset_permissions(auth_tokens_path)
    except FileNotFoundError:
        pass
    if flags["debug"]:
        print(f"file contents: ")
        print(json.dumps(data, indent=4))
    return data


def write_to_app_state(data: dict):
    current_data = read_app_state()
    new_data = {**current_data, **data}
    auth_tokens_path = get_app_state_file_path()

    if flags["debug"]:
        print(f"writing to auth_tokens_path: {auth_tokens_path}")
        print(f"file contents: ")
        print(json.dumps(new_data, indent=4))

    with auth_tokens_path.open("w", encoding="UTF-8") as app_state_file:
        json.dump(new_data, app_state_file)
    reset_permissions(auth_tokens_path)


def read_auth_tokens():
    file_contents = read_app_state()
    return file_contents.get("tokens")


def get_sub(id_token: str):
    claims = jwt.decode(
        id_token,
        # We don't need to verify the signature since the ID
        # token will be verified by the API every time we send it
        options={"verify_signature": False},
    )
    return claims.get("sub")


def refresh_auth_tokens(current_tokens: dict):
    if flags["debug"]:
        print("Refreshing tokens...")
    refresh_token = current_tokens["refreshToken"]
    id_token = current_tokens["idToken"]
    sub = get_sub(id_token)
    if not sub:
        raise ExitError("Could not get sub from ID token")

    response = requests.post(
        f"{auth_url}/refresh", json={"refreshToken": refresh_token, "sub": sub}
    )
    handle_request_errors(response=response)

    response_body = response.json()
    refreshed_tokens = response_body["tokens"]
    tokens = {**current_tokens, **refreshed_tokens}
    write_to_app_state({"tokens": tokens})
    return tokens


def get_api_credentials():
    if flags["debug"]:
        print("Fetching AWS credentials...")

    app_state = read_app_state()

    request_body = {}
    current_tokens = app_state.get("tokens")
    identity_id = app_state.get("identityId")
    if current_tokens:
        # Need to refresh tokens to make sure the claims are current
        tokens = refresh_auth_tokens(current_tokens)
        request_body["idToken"] = tokens["idToken"]
    if identity_id:
        # elif because we should only add identity id if not authenticated
        request_body["identityId"] = identity_id

    if flags["debug"]:
        print(f"request_body: {request_body}")

    response = requests.post(f"{auth_url}/aws-creds", json=request_body)
    handle_request_errors(response=response)
    response_data = response.json()
    # Cache identity id to prevent the creation of duplicate identities
    write_to_app_state({"identityId": response_data.get("identityId")})

    return response_data


def is_logged_in():
    tokens = read_auth_tokens()
    return tokens is not None


def get_password():
    return getpass.getpass()


def should_reauthenticate():
    tokens = read_auth_tokens()
    if not tokens:
        # Do not need to reauthenticate since the user never
        # authenticated in the first place
        return False
    refresh_expires = datetime.fromtimestamp(tokens["refreshExpires"])
    reauth_after = refresh_expires - BUFFER_TIME
    return reauth_after <= datetime.now()


def login_user(email: str, password: str):
    print("Authenticating...")
    response = requests.post(
        f"{auth_url}/login", json={"username": email, "password": password}
    )

    handle_request_errors(response=response)

    response_body = response.json()
    refresh_expires = datetime.now() + REFRESH_LIFE_SPAN
    tokens = {
        **response_body["tokens"],
        "refreshExpires": refresh_expires.timestamp(),
    }
    # Need to clear identity id since it is no longer valid
    write_to_app_state({"tokens": tokens, "identityId": None})
    print("[green]Login successful![/green]")


def logout_user():
    write_to_app_state({"tokens": None, "identityId": None})
    print("[green]Logout successful![/green]")
