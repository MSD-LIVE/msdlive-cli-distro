import typer
from rich.console import Console
from pathlib import Path
import sys
import platform

from .auth import login_user, logout_user
from .file_transfer import download_dataset, upload_dataset
from .flags import flags

error_console = Console(stderr=True)
app = typer.Typer()


@app.callback()
def callback(debug: bool = False):
    """
    MSD-LIVE's command line interface
    """
    flags["debug"] = debug
    not_tty = not sys.stdin.isatty()
    is_windows = platform.system() == "Windows"
    if not_tty:
        # notify user that they have a bad terminal
        # perhaps if os.name == 'nt': , prompt them to use winpty?
        error_console.print(
            "[red]ERROR: Your terminal is not compatible with this program[/red]"
        )
        if is_windows:
            error_console.print(
                "[yellow]winpty should fix this issue. Try running: [/yellow]"
            )
            error_console.print(
                f"[yellow]winpty msdlive {' '.join(sys.argv[1:])}[/yellow]"
            )
        raise typer.Exit(1)


@app.command()
def login():
    """Login to MSD-LIVE"""
    try:
        login_user(error_console=error_console)
    except Exception as e:
        if flags["debug"]:
            raise e
        else:
            error_console.print(f"[red]{str(e)}[/red]")


@app.command()
def logout():
    """Logout of MSD-LIVE"""
    try:
        logout_user(error_console=error_console)
    except Exception as e:
        if flags["debug"]:
            raise e
        else:
            error_console.print(f"[red]{str(e)}[/red]")


@app.command()
def download(
    output_dir: Path = typer.Option(..., help="Local directory to save the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
):
    """Download a dataset

    This command will do the minimum amount of work to ensure that the most
    recent versions of the the files in the dataset are downloaded to the
    local directory. This means the command can be run multiple times as
    the files in the dataset change. The command can be safely restarted
    if it is stopped part way through a download.



    A file will be downloaded from the dataset if the size differs from
    the size of the local file, the last modified time is newer than
    the last modified time of the local file, or the file does not
    exist in the local directory. When files are downloaded, the last
    modified time of the local file is changed to the last modified
    time of the file in the dataset.
    """
    try:
        download_dataset(
            error_console=error_console,
            dataset_id=dataset_id,
            dst_dir=output_dir,
        )
    except Exception as e:
        if flags["debug"]:
            raise e
        else:
            error_console.print(f"[red]{str(e)}[/red]")


@app.command()
def upload(
    src_dir: Path = typer.Option(..., help="Local directory containing the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
):
    """Upload files to a dataset

    This command will do the minimum amount of work to upload the local files
    to the dataset, potentially overwriting older versions. This means the
    command can be run multiple times as files are added or modified. The
    command can also be safely restarted if it was stopped part way
    through an upload.



    A local file will be uploaded if the size of the local file
    is different than the size of file in the dataset, the last
    modified time of the local file is newer than the last
    modified time of the file in the dataset, or the local file
    does not exist in the dataset.
    """
    try:
        upload_dataset(
            error_console=error_console,
            src_dir=src_dir,
            dataset_id=dataset_id,
        )
    except Exception as e:
        if flags["debug"]:
            raise e
        else:
            error_console.print(f"[red]{str(e)}[/red]")
