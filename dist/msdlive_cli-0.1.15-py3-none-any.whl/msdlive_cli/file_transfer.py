from pathlib import Path
from rich import print
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from enum import Enum, auto

from .auth import get_api_credentials, should_reauthenticate, login_user
from .aws_cli_connection import run_aws_cli_command


def get_access_point_arn(dataset_id: str, region: str, account_id: str):
    access_point_name = dataset_id
    return f"arn:aws:s3:{region}:{account_id}:accesspoint/{access_point_name}"


class TransferDirection(Enum):
    UPLOAD = auto()
    DOWNLOAD = auto()


def transfer_files(
    error_console: Console,
    local_dir: Path,
    dataset_id: str,
    direction,
):
    if should_reauthenticate(error_console):
        print("Your session has expired. Please reauthenticate.")
        login_user(error_console)

    api_credentials = get_api_credentials(error_console=error_console)
    access_point_arn = get_access_point_arn(
        dataset_id=dataset_id,
        region=api_credentials["region"],
        account_id=api_credentials["accountId"],
    )

    s3_path = f"s3://{access_point_arn}/{dataset_id}"
    local_path = str(local_dir)
    cmd = ["s3", "sync"]
    task_description = "Downloading..."
    if direction is TransferDirection.DOWNLOAD:
        cmd.extend([s3_path, local_path])
    elif direction is TransferDirection.UPLOAD:
        cmd.extend([local_path, s3_path])
        task_description = "Uploading..."

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(description=task_description, total=None)
        run_aws_cli_command(
            cmd=cmd,
            api_credentials=api_credentials,
            error_console=error_console,
        )


def upload_dataset(error_console: Console, src_dir: Path, dataset_id: str):
    transfer_files(
        error_console=error_console,
        local_dir=src_dir,
        dataset_id=dataset_id,
        direction=TransferDirection.UPLOAD,
    )


def download_dataset(error_console: Console, dst_dir: Path, dataset_id: str):
    transfer_files(
        error_console=error_console,
        local_dir=dst_dir,
        dataset_id=dataset_id,
        direction=TransferDirection.DOWNLOAD,
    )
