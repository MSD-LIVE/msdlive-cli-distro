environment_name = "stage"
auth_url = "https://7nowadm7q0.execute-api.us-west-2.amazonaws.com/prod"
help_url = "https://stage.msdlive.org/cli-help"
