from datetime import datetime

from botocore.session import Session
from botocore.credentials import RefreshableCredentials


def now():
    return datetime.now()


class RefreshableSession(Session):
    def __init__(self, *args, init_aws_creds=None, refresh_handler=None, **kwargs):
        if not refresh_handler:
            raise RuntimeError("refresh_handler required")
        if not init_aws_creds:
            raise RuntimeError("init_aws_creds required")

        self._refreshable_credentials = RefreshableCredentials(
            access_key=init_aws_creds["access_key"],
            secret_key=init_aws_creds["secret_key"],
            token=init_aws_creds["token"],
            expiry_time=datetime.fromisoformat(init_aws_creds["expiry_time"]),
            refresh_using=refresh_handler,
            method="explicit",
            time_fetcher=now,
        )

        super().__init__(*args, **kwargs)

    def get_credentials(self):
        """
        Return the :class:`botocore.credential.Credential` object
        associated with this session.  If the credentials have not
        yet been loaded, this will attempt to load them.  If they
        have already been loaded, this will return the cached
        credentials.

        """
        return self._refreshable_credentials
