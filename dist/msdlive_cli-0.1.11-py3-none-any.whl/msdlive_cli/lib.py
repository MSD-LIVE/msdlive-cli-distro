from pathlib import Path

import typer
import requests
import rich

from .config import environment_name


def get_app_path() -> Path:
    app_name = f"msdlive-cli-{environment_name}"
    app_path: Path = Path(typer.get_app_dir(app_name))
    app_path.mkdir(exist_ok=True)
    return app_path


def handle_request_errors(
    response: requests.Response, error_console: rich.console.Console
):
    if response.status_code >= 400 and response.status_code < 500:
        error_console.print("[red]Login failed[/red]")
        error_body = response.json() or {}
        error_message = error_body.get("message")
        if error_message:
            error_console.print(f"[red]{error_message}[/red]")
        raise typer.Exit(1)
    if response.status_code >= 500:
        error_console.print("[red]Login failed with unexpected error[/red]")
        error_console.print("[red]Please email info@msdlive.org for assistance[/red]")
        raise typer.Exit(1)
