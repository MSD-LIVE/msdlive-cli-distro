import toml


class Config:
    def __init__(self) -> None:
        config_contents = self.get_config_file_contents()
        self.auth_url = config_contents.get("auth_url")
        self.environment_name = config_contents.get("environment_name")

    def get_config_file_contents(self):
        # The local config is for developers to keep their development config.
        # Having a separate file allows them to publish the package to
        # different environments without overwriting their local config.
        possible_configs = ["local.msdlive_config.toml", "msdlive_config.toml"]
        for filename in possible_configs:
            try:
                with open(filename, "r") as pyproject_file:
                    return toml.load(pyproject_file)
            except FileNotFoundError:
                # Move onto next config file
                pass
