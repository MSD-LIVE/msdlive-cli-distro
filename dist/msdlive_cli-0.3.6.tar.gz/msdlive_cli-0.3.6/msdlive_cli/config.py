environment_name = "dev"
auth_url = "https://4w5dld7rr8.execute-api.us-west-2.amazonaws.com/prod"
