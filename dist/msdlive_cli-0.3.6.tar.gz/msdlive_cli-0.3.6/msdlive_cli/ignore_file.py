from pathlib import Path
from typing import List, Optional


class S3PatternFlag:
    def __init__(self, pattern) -> None:
        pass

    def to_cli_option(self):
        raise RuntimeError("Not implemented")


class S3ExcludeFlag(S3PatternFlag):
    def __init__(self, pattern) -> None:
        self.pattern = pattern

    def to_cli_option(self):
        return ["--exclude", self.pattern]


class S3IncludeFlag(S3PatternFlag):
    def __init__(self, pattern) -> None:
        self.pattern = pattern

    def to_cli_option(self):
        return ["--include", self.pattern]


class IgnoreFile:
    def __init__(self, ignore_file: Path) -> None:
        self.flags = self._parse_file(ignore_file)

    @staticmethod
    def parse_cli_option(ignore_file: Optional[Path]):
        if ignore_file:
            return IgnoreFile(ignore_file)
        return None

    def _parse_file(self, ignore_file: Path) -> List[S3PatternFlag]:
        flags: S3PatternFlag = []
        with ignore_file.open() as ignore_file_obj:
            for line in ignore_file_obj:
                parsed_line = self._parse_pattern(line)
                if parsed_line:
                    flags.append(parsed_line)
        return flags

    def _parse_pattern(self, ignore_pattern: str) -> Optional[S3PatternFlag]:
        pattern = ignore_pattern.strip()
        if pattern.startswith("!"):
            pattern = pattern[1:]
            FlagClass = S3IncludeFlag
        else:
            FlagClass = S3ExcludeFlag
        if not pattern:
            return None
        return FlagClass(pattern)
