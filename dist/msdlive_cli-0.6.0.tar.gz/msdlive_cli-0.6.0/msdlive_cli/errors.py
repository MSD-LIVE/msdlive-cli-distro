from typer import Exit as TyperExit
from rich.console import Console

error_console = Console(stderr=True)


class ExitError(TyperExit):
    def __init__(self, *messages: str, code: int = 1) -> None:
        for msg in messages:
            error_console.print(f"[red]{msg}[/red]")
        super().__init__(code)
