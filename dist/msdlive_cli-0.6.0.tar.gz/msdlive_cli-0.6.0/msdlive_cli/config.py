environment_name = "prod"
auth_url = "https://9ais97ik88.execute-api.us-west-2.amazonaws.com/prod"
help_url = "https://msdlive.org/cli-help"
