import json
import requests
import jwt
from rich import print
from rich.console import Console

from .lib import get_app_path, handle_request_errors
from .config import Config

# TODO: put this a .env file or similar
# TODO: version the API so that old installations of this package
# will continue to work if we change the API
AUTH_URL = "https://5j36a8tb1k.execute-api.us-west-2.amazonaws.com/prod"


class AlreadyLoggedIn(Exception):
    pass


class NotAuthenticated(Exception):
    pass


def get_auth_tokens_path(config: Config):
    return get_app_path(config) / "auth-tokens.json"


def write_auth_tokens(config: Config, tokens=None):
    auth_tokens_path = get_auth_tokens_path(config)
    with auth_tokens_path.open("w", encoding="UTF-8") as tokens_file:
        json.dump({"tokens": tokens}, tokens_file)


def read_auth_tokens(config: Config):
    auth_tokens_path = get_auth_tokens_path(config)
    with auth_tokens_path.open(encoding="UTF-8") as tokens_file:
        contents = json.load(tokens_file)
        return contents["tokens"]


def get_sub(id_token: str):
    claims = jwt.decode(
        id_token,
        # We don't need to verify the signature since the ID
        # token will be verified by the API every time we send it
        options={"verify_signature": False},
    )
    return claims.get("sub")


def refresh_auth_tokens(config: Config, error_console: Console, current_tokens: dict):
    print("Refreshing tokens...")
    refresh_token = current_tokens["refreshToken"]
    id_token = current_tokens["idToken"]
    sub = get_sub(id_token)
    if not sub:
        raise RuntimeError("Could not get sub from ID token")

    response = requests.post(
        f"{config.auth_url}/refresh", json={"refreshToken": refresh_token, "sub": sub}
    )
    handle_request_errors(response=response, error_console=error_console)

    refreshed_tokens = response.json()
    tokens = {**current_tokens, **refreshed_tokens}
    write_auth_tokens(config=config, tokens=tokens)
    return tokens


def get_aws_credentials(config: Config, error_console: Console):
    tokens = read_auth_tokens(config)
    if not tokens:
        raise NotAuthenticated("Must be logged in to perform this action")

    # Need to refresh tokens to make sure the claims are current
    tokens = refresh_auth_tokens(
        config=config, error_console=error_console, current_tokens=tokens
    )

    print("Fetching AWS credentials...")
    response = requests.post(
        f"{config.auth_url}/aws-creds", json={"idToken": tokens["idToken"]}
    )
    handle_request_errors(response=response, error_console=error_console)

    return response.json()


def is_logged_in(config: Config):
    tokens = read_auth_tokens(config)
    return tokens is not None


def login_user(config: Config, error_console: Console, username, password):
    print("Authenticating...")
    response = requests.post(
        f"{config.auth_url}/login", json={"username": username, "password": password}
    )

    handle_request_errors(response=response, error_console=error_console)

    response_body = response.json()
    write_auth_tokens(config=config, tokens=response_body["tokens"])
    print("[green]Login successful![/green]")


def logout_user(config: Config, error_console: Console):
    write_auth_tokens(config=config, tokens=None)
    print("[green]Logout successful![/green]")
