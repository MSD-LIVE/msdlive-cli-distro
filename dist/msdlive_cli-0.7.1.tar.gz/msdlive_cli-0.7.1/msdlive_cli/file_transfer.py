from pathlib import Path
from rich import print
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from enum import Enum, auto
from typing import Optional

from .auth import get_api_credentials, should_reauthenticate, ReAuthReason, login_user
from .aws_cli_connection import run_aws_cli_command
from .ignore_file import IgnoreFile
from .errors import ExitError


def get_access_point_arn(dataset_id: str, region: str, account_id: str):
    access_point_name = dataset_id
    return f"arn:aws:s3:{region}:{account_id}:accesspoint/{access_point_name}"


class TransferDirection(Enum):
    UPLOAD = auto()
    DOWNLOAD = auto()


def transfer_files(
    local_dir: Path,
    dataset_id: str,
    direction: TransferDirection,
    ignore_file: Optional[IgnoreFile],
    quiet: bool,
    delete: bool = False,
):
    auth_required, reason = should_reauthenticate()
    if auth_required:
        if reason is ReAuthReason.NEVER_LOGGED_IN:
            print("You must log in to access data.")
        elif reason is ReAuthReason.SESSION_EXPIRED:
            print("Your session has expired.")
        login_user()
    if not local_dir.exists():
        raise ExitError(f"{local_dir.resolve()} does not exist")
    if local_dir.is_file():
        raise ExitError(f"{local_dir.resolve()} is not a directory")

    api_credentials = get_api_credentials()
    access_point_arn = get_access_point_arn(
        dataset_id=dataset_id,
        region=api_credentials["region"],
        account_id=api_credentials["accountId"],
    )

    s3_path = f"s3://{access_point_arn}/{dataset_id}"
    local_path = str(local_dir)
    cmd = ["s3", "sync"]
    task_description = "Downloading..."
    if direction is TransferDirection.DOWNLOAD:
        cmd.extend([s3_path, local_path])
    elif direction is TransferDirection.UPLOAD:
        cmd.extend([local_path, s3_path])
        task_description = "Uploading..."
    if ignore_file:
        for flag in ignore_file.flags:
            cmd.extend(flag.to_cli_option())
    if delete:
        cmd.append("--delete")
    if quiet:
        cmd.append("--quiet")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(description=task_description, total=None)
        run_aws_cli_command(
            cmd=cmd,
            api_credentials=api_credentials,
        )


def upload_dataset(
    src_dir: Path,
    dataset_id: str,
    delete: bool,
    quiet: bool,
    ignore_file: Optional[IgnoreFile],
):
    transfer_files(
        local_dir=src_dir,
        dataset_id=dataset_id,
        direction=TransferDirection.UPLOAD,
        delete=delete,
        quiet=quiet,
        ignore_file=ignore_file,
    )


def download_dataset(
    dst_dir: Path,
    dataset_id: str,
    quiet: bool,
    ignore_file: Optional[IgnoreFile],
):
    transfer_files(
        local_dir=dst_dir,
        dataset_id=dataset_id,
        direction=TransferDirection.DOWNLOAD,
        quiet=quiet,
        ignore_file=ignore_file,
    )
