from pathlib import Path

import typer
import requests
import rich

from .config import environment_name
from .flags import flags
from .errors import ExitError


def get_app_path() -> Path:
    app_name = f"msdlive-cli-{environment_name}"
    app_path: Path = Path(typer.get_app_dir(app_name))
    permissions = 0o700
    app_path.mkdir(mode=permissions, parents=True, exist_ok=True)
    # In case the directory already existed, make sure it has the right permissions
    app_path.chmod(permissions)
    return app_path


def handle_request_errors(
    response: requests.Response,
):
    if response.status_code < 400:
        # There isn't an error
        return
    messages = ["Request failed"]
    if response.status_code >= 400 and response.status_code < 500:
        error_body = response.json() or {}
        error_message = error_body.get("message")
        if "Token expired" in error_message:
            if flags["debug"]:
                messages.append(error_message)
            messages.append(
                "Your authentication token expired, run the msdlive login command"
            )
        else:
            messages.append(error_message)
    if response.status_code >= 500:
        messages.append("Unexpected error")
        messages.append("Please email info@msdlive.org if this error persists")
        if flags["debug"]:
            error_body = response.json() or {}
            messages.append(error_body)
    raise ExitError(*messages)
