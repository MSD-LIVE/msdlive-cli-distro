import os

import typer
from rich.console import Console
from awscli.clidriver import AWSCLIEntryPoint

# https://github.com/boto/boto3/issues/358#issuecomment-372086466
def run_aws_cli_command(cmd: list[str], aws_credentials: dict, error_console: Console):
    """Run a CLI command
    cmd: An array of cli args (e.g. ["s3", "ls"])
    credentials: A dictionary with credentials retrieved from
        the /aws-creds endpoint.
    error_console: Rich error console to log errors
    """
    old_env = dict(os.environ)
    try:
        env = os.environ.copy()
        env["LC_CTYPE"] = "en_US.UTF"
        env["AWS_ACCESS_KEY_ID"] = aws_credentials["credentials"]["accessKeyId"]
        env["AWS_SECRET_ACCESS_KEY"] = aws_credentials["credentials"]["secretKey"]
        env["AWS_SESSION_TOKEN"] = aws_credentials["credentials"]["sessionToken"]
        env["AWS_DEFAULT_REGION"] = aws_credentials["region"]
        os.environ.update(env)

        # Run awscli in the same process
        exit_code = AWSCLIEntryPoint().main(cmd)

        if exit_code > 0:
            cmd_str = " ".join(cmd)
            error_console.print(f"[red]Failed to run AWS command: {cmd_str}[/red]")
            typer.Exit(1)
    finally:
        os.environ.clear()
        os.environ.update(old_env)
