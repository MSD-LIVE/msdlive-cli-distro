environment_name = "stage"
# TODO: Fill in stage auth URL
auth_url = ""
