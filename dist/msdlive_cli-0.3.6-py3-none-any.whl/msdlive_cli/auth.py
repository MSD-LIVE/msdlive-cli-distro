import json
import requests
import jwt
from rich import print
from rich.console import Console
import typer
import getpass
from datetime import datetime, timedelta

from .lib import get_app_path, handle_request_errors
from .config import auth_url
from .flags import flags

# Amount of time the refresh token is valid for
REFRESH_LIFE_SPAN = timedelta(days=2)
# Time before refresh token expires when user should reauthenticate
BUFFER_TIME = timedelta(days=1)


class AlreadyLoggedIn(Exception):
    pass


class NotAuthenticated(Exception):
    pass


def get_auth_tokens_path():
    return get_app_path() / "auth-tokens.json"


def write_auth_tokens(tokens=None):
    auth_tokens_path = get_auth_tokens_path()
    if flags["debug"]:
        print(f"writing tokens to auth_tokens_path: {auth_tokens_path}")
        print("tokens: ")
        print(json.dumps(tokens, indent=4))
    with auth_tokens_path.open("w", encoding="UTF-8") as tokens_file:
        json.dump({"tokens": tokens}, tokens_file)


def read_auth_tokens():
    auth_tokens_path = get_auth_tokens_path()
    if flags["debug"]:
        print(f"reading tokens from auth_tokens_path: {auth_tokens_path}")
    with auth_tokens_path.open(encoding="UTF-8") as tokens_file:
        contents = json.load(tokens_file)
        tokens = contents["tokens"]
        if flags["debug"]:
            print("tokens: ")
            print(json.dumps(tokens, indent=4))
        return tokens


def get_sub(id_token: str):
    claims = jwt.decode(
        id_token,
        # We don't need to verify the signature since the ID
        # token will be verified by the API every time we send it
        options={"verify_signature": False},
    )
    return claims.get("sub")


def refresh_auth_tokens(error_console: Console, current_tokens: dict):
    if flags["debug"]:
        print("Refreshing tokens...")
    refresh_token = current_tokens["refreshToken"]
    id_token = current_tokens["idToken"]
    sub = get_sub(id_token)
    if not sub:
        raise RuntimeError("Could not get sub from ID token")

    response = requests.post(
        f"{auth_url}/refresh", json={"refreshToken": refresh_token, "sub": sub}
    )
    handle_request_errors(response=response, error_console=error_console)

    response_body = response.json()
    refreshed_tokens = response_body["tokens"]
    tokens = {**current_tokens, **refreshed_tokens}
    write_auth_tokens(tokens=tokens)
    return tokens


def get_api_credentials(error_console: Console):
    if flags["debug"]:
        print("Fetching AWS credentials...")

    tokens = read_auth_tokens()

    request_body = {}
    if tokens:
        # Need to refresh tokens to make sure the claims are current
        tokens = refresh_auth_tokens(error_console=error_console, current_tokens=tokens)
        request_body["idToken"] = tokens["idToken"]

    response = requests.post(f"{auth_url}/aws-creds", json=request_body)
    handle_request_errors(response=response, error_console=error_console)

    return response.json()


def is_logged_in():
    tokens = read_auth_tokens()
    return tokens is not None


def get_password(error_console: Console):
    return getpass.getpass()


def should_reauthenticate(error_console: Console):
    tokens = read_auth_tokens()
    if not tokens:
        # Do not need to reauthenticate since the user never
        # authenticated in the first place
        return False
    refresh_expires = datetime.fromtimestamp(tokens["refreshExpires"])
    reauth_after = refresh_expires - BUFFER_TIME
    return reauth_after <= datetime.now()


def login_user(error_console: Console):
    email = typer.prompt("Email")
    password = get_password(error_console=error_console)

    print("Authenticating...")
    response = requests.post(
        f"{auth_url}/login", json={"username": email, "password": password}
    )

    handle_request_errors(response=response, error_console=error_console)

    response_body = response.json()
    refresh_expires = datetime.now() + REFRESH_LIFE_SPAN
    tokens = {
        **response_body["tokens"],
        "refreshExpires": refresh_expires.timestamp(),
    }
    write_auth_tokens(tokens=tokens)
    print("[green]Login successful![/green]")


def logout_user(error_console: Console):
    write_auth_tokens(tokens=None)
    print("[green]Logout successful![/green]")
