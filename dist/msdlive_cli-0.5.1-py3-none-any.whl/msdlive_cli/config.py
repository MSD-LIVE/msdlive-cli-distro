environment_name = "prod"
# TODO: Fill in prod auth URL
auth_url = ""
help_url = "https://msdlive.org/cli-help"
