import os
from datetime import datetime

from rich.console import Console
from awscli.clidriver import CLIDriver, AWSCLIEntryPoint, _set_user_agent_for_session
from awscli.argparser import FirstPassGlobalArgParser
from awscli.plugin import load_plugins
from awscli.errorhandler import construct_cli_error_handlers_chain

from .auth import get_api_credentials
from .refreshable_session import RefreshableSession
from .flags import flags
from .errors import ExitError


def api_creds_to_cli_creds(api_creds):
    expiration = api_creds["credentials"]["expiration"]
    return {
        "access_key": api_creds["credentials"]["accessKeyId"],
        "secret_key": api_creds["credentials"]["secretKey"],
        "token": api_creds["credentials"]["sessionToken"],
        "expiry_time": datetime.fromtimestamp(expiration).isoformat(),
    }


def refresh_handler():
    api_credentials = get_api_credentials()
    return api_creds_to_cli_creds(api_credentials)


def create_clidriver(api_credentials: dict, args=None):
    debug = None
    if args is not None:
        parser = FirstPassGlobalArgParser()
        args, _ = parser.parse_known_args(args)
        debug = args.debug
    session = RefreshableSession(
        init_aws_creds=api_creds_to_cli_creds(api_credentials),
        refresh_handler=refresh_handler,
    )
    _set_user_agent_for_session(session)
    load_plugins(
        session.full_config.get("plugins", {}),
        event_hooks=session.get_component("event_emitter"),
    )
    error_handlers_chain = construct_cli_error_handlers_chain()
    driver = CLIDriver(session=session, error_handler=error_handlers_chain, debug=debug)
    return driver


# https://github.com/boto/boto3/issues/358#issuecomment-372086466
def run_aws_cli_command(cmd: list[str], api_credentials: dict):
    """Run a CLI command
    cmd: An array of cli args (e.g. ["s3", "ls"])
    credentials: A dictionary with credentials retrieved from
        the /aws-creds endpoint.
    """
    if flags["debug"]:
        cmd.append("--debug")
        print(f'aws cli command: {" ".join(cmd)}')

    old_env = dict(os.environ)
    try:
        env = os.environ.copy()
        env["LC_CTYPE"] = "en_US.UTF"
        env["AWS_DEFAULT_REGION"] = api_credentials["region"]
        os.environ.update(env)

        # Run awscli in the same process
        driver = create_clidriver(api_credentials, cmd)
        exit_code = AWSCLIEntryPoint(driver=driver).main(cmd)

        if exit_code > 0:
            raise ExitError(
                "Failed to sync files",
                "If this is a private dataset you may need to login",
                "There may be additional error output above",
            )
    finally:
        os.environ.clear()
        os.environ.update(old_env)
