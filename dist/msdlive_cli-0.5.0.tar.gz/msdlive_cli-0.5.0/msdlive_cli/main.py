import typer
from rich.console import Console
from pathlib import Path
import sys
import platform

from .auth import login_user, logout_user
from .file_transfer import download_dataset, upload_dataset
from .flags import flags
from .ignore_file import IgnoreFile
from .errors import ExitError
from .config import help_url


app = typer.Typer(rich_markup_mode="markdown")


def get_full_cmd_help(help):
    return f"{help}\n\n\n See {help_url} for more details."


@app.callback(help=get_full_cmd_help("MSD-LIVE's command line interface."))
def callback(debug: bool = False):
    flags["debug"] = debug
    not_tty = not sys.stdin.isatty()
    is_windows = platform.system() == "Windows"
    if not_tty:
        # notify user that they have a bad terminal
        messages = ["Your terminal is not compatible with this program"]
        if is_windows:
            messages.append("winpty should fix this issue. Try running:")
            messages.append(f"winpty msdlive {' '.join(sys.argv[1:])}")
        raise ExitError(*messages)


@app.command(help=get_full_cmd_help("Login to MSD-LIVE."))
def login():
    login_user()


@app.command(help=get_full_cmd_help("Logout of MSD-LIVE."))
def logout():
    logout_user()


@app.command(help=get_full_cmd_help("Download files from a dataset."))
def download(
    output_dir: Path = typer.Option(..., help="Local directory to save the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
    quiet: bool = typer.Option(
        False,
        help="Hide output during download",
    ),
    filter_file: Path = typer.Option(
        None,
        help=f"YAML configuration file used to download a subset of files",
    ),
):
    download_dataset(
        dataset_id=dataset_id,
        dst_dir=output_dir,
        ignore_file=IgnoreFile.parse_cli_option(filter_file),
        quiet=quiet,
    )


@app.command(help=get_full_cmd_help("Upload files to a dataset."))
def upload(
    src_dir: Path = typer.Option(..., help="Local directory containing the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
    quiet: bool = typer.Option(False, help="Hide output during upload"),
    delete: bool = typer.Option(
        False, help="Delete files in MSD-LIVE that do not exist in src_dir"
    ),
    filter_file: Path = typer.Option(
        None,
        help=f"YAML configuration file used to upload a subset of files",
    ),
):
    upload_dataset(
        src_dir=src_dir,
        dataset_id=dataset_id,
        delete=delete,
        quiet=quiet,
        ignore_file=IgnoreFile.parse_cli_option(filter_file),
    )
