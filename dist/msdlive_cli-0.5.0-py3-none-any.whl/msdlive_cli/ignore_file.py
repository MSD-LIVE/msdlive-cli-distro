from pathlib import Path
from typing import List, Optional
import yaml

from .errors import ExitError


class S3PatternFlag:
    def __init__(self, pattern) -> None:
        pass

    def to_cli_option(self):
        raise RuntimeError("Not implemented")


class S3ExcludeFlag(S3PatternFlag):
    def __init__(self, pattern) -> None:
        self.pattern = pattern

    def to_cli_option(self):
        return ["--exclude", self.pattern]


class S3IncludeFlag(S3PatternFlag):
    def __init__(self, pattern) -> None:
        self.pattern = pattern

    def to_cli_option(self):
        return ["--include", self.pattern]


class IgnoreFile:
    def __init__(self, ignore_file: Path) -> None:
        self.flags = self._parse_file(ignore_file)

    @staticmethod
    def parse_cli_option(ignore_file: Optional[Path]):
        if ignore_file:
            return IgnoreFile(ignore_file)
        return None

    def _parse_pattern_list(self, pattern_list, name) -> bool:
        if type(pattern_list) is not list:
            raise ExitError(f'"{name}" must be an array')
        parsed_patterns: List[str] = []
        for pattern in pattern_list:
            if type(pattern) is not str:
                raise ExitError(f'"{pattern}" is invalid: must be a string')
            stripped_pattern = pattern.strip()
            if stripped_pattern:
                parsed_patterns.append(stripped_pattern)
        if len(parsed_patterns) == 0:
            raise ExitError(f'"{name}" must have at least one non-empty value', code=1)
        return parsed_patterns

    def _parse_file(self, ignore_file: Path) -> List[S3PatternFlag]:
        exclude_key = "exclude"
        include_key = "except"
        flags: List[S3PatternFlag] = []
        with ignore_file.open(mode="rt", encoding="utf-8") as ignore_file_obj:
            contents = yaml.safe_load(ignore_file_obj)
            invalid_file_format_messages = [
                f"{ignore_file.name} is invalid",
                f'It must contain the "{exclude_key}" array',
                f'It can optionally contain the "{include_key}" array',
                "It can not contain any other values",
            ]
            if type(contents) is not dict:
                raise ExitError(*invalid_file_format_messages)

            contents_has_extra_keys = any(
                [item not in [exclude_key, include_key] for item in contents.keys()]
            )
            if contents_has_extra_keys:
                raise ExitError(*invalid_file_format_messages)

            exclude = contents.get(exclude_key, None)
            include = contents.get(include_key, None)
            if not exclude:
                raise ExitError(f'Must supply "{exclude_key}" array')
            parsed_exclude = self._parse_pattern_list(
                pattern_list=exclude, name=exclude_key
            )
            parsed_include = (
                self._parse_pattern_list(pattern_list=include, name=include_key)
                if include
                else None
            )
            for pattern in parsed_exclude:
                flags.append(S3ExcludeFlag(pattern))
            for pattern in parsed_include:
                flags.append(S3IncludeFlag(pattern))
        return flags
