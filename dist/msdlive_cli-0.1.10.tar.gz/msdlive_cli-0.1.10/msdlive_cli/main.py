import typer
from rich.console import Console
from pathlib import Path

from .auth import login_user, logout_user
from .file_transfer import download_dataset, upload_dataset

error_console = Console(stderr=True)
app = typer.Typer()


@app.callback()
def callback():
    """
    MSD-LIVE's command line interface
    """
    pass


@app.command()
def login():
    """Login to MSD-LIVE"""
    login_user(error_console=error_console)


@app.command()
def logout():
    """Logout of MSD-LIVE"""
    logout_user(error_console=error_console)


@app.command()
def download(
    output_dir: Path = typer.Option(..., help="Directory to save the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
):
    """Download a dataset"""
    download_dataset(
        error_console=error_console,
        dataset_id=dataset_id,
        dst_dir=output_dir,
    )


@app.command()
def upload(
    src_dir: Path = typer.Option(..., help="Directory containing the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
):
    """Upload files to a dataset"""
    upload_dataset(
        error_console=error_console,
        src_dir=src_dir,
        dataset_id=dataset_id,
    )
