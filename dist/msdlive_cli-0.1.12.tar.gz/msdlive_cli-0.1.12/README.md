# MSD-LIVE CLI

A CLI for managing [MSD-LIVE](https://msdlive.org) data.

## Install

`pip install msdlive-cli`

## Usage

Run `msdlive --help` to see usage information.
