# only used from vs code's debugger 
from msdlive_cli import main

if __name__ == "__main__":
    main.app()
