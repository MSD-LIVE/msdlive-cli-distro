environment_name = "prod"
auth_url = "https://4bt2hmd151.execute-api.us-west-2.amazonaws.com/prod"
help_url = "https://msdlive.org/cli-help"
