from pathlib import Path

import typer
import requests
import re

from .config import environment_name
from .flags import flags
from .errors import ExitError


def get_app_path() -> Path:
    app_name = f"msdlive-cli-{environment_name}"
    app_path: Path = Path(typer.get_app_dir(app_name))
    permissions = 0o700
    app_path.mkdir(mode=permissions, parents=True, exist_ok=True)
    # In case the directory already existed, make sure it has the right permissions
    app_path.chmod(permissions)
    return app_path


def handle_request_errors(
    response: requests.Response,
):
    if response.status_code < 400:
        # There isn't an error
        return
    messages = ["Request failed"]
    if response.status_code >= 400 and response.status_code < 500:
        error_body = response.json() or {}
        error_message = error_body.get("message")
        if "Token expired" in error_message:
            if flags["debug"]:
                messages.append(error_message)
            messages.append(
                "Your authentication token expired, run the msdlive login command"
            )
        else:
            messages.append(error_message)
    if response.status_code >= 500:
        messages.append("Unexpected error")
        messages.append("Please email info@msdlive.org if this error persists")
        if flags["debug"]:
            error_body = response.json() or {}
            messages.append(error_body)
    raise ExitError(*messages)


def _email_to_access_point(email: str) -> str:
    # Convert to lowercase and replace invalid characters with hyphens
    email = email.lower()
    email = re.sub(
        r"[^a-z0-9-]", "-", email
    )  # Keep only lowercase letters, numbers, and hyphens

    # add dev as prefix if not prod
    email = (
        email
        if environment_name == "prod"
        else f"{environment_name}-{email}"
    )

    # Ensure the access point name doesn't start or end with a hyphen
    email = email.strip("-")

    # Truncate to 50 characters and avoid ending with '-s3alias'
    email = email[:50]
    if email.endswith("-s3alias"):
        email = email[:-8]

    # Handle potential trailing hyphen after truncation
    email = email.rstrip("-")

    # Ensure minimum length of 3 characters
    if len(email) < 3:
        email = (email + "abc")[:3]

    return email

def get_access_point_arn(dataset_id: str, region: str, account_id: str, scratch: bool, email: str):
    if scratch:
        # access point arns for scratch dirs are named using 
        # hard coding for now to test
        # access_point_name = f"dev-admin-msdlive-org"
        access_point_name = _email_to_access_point(email)
    else:
        access_point_name = dataset_id
    return f"arn:aws:s3:{region}:{account_id}:accesspoint/{access_point_name}"
