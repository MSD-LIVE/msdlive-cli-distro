import os
import sys
from datetime import datetime
from io import StringIO

from rich.console import Console
from awscli.clidriver import CLIDriver, AWSCLIEntryPoint, _set_user_agent_for_session
from awscli.argparser import FirstPassGlobalArgParser
from awscli.plugin import load_plugins
from awscli.errorhandler import construct_cli_error_handlers_chain

from .auth import get_api_credentials
from .refreshable_session import RefreshableSession
from .flags import flags
from .errors import ExitError


def api_creds_to_cli_creds(api_creds):
    expiration = api_creds["credentials"]["expiration"]
    return {
        "access_key": api_creds["credentials"]["accessKeyId"],
        "secret_key": api_creds["credentials"]["secretKey"],
        "token": api_creds["credentials"]["sessionToken"],
        "expiry_time": datetime.fromtimestamp(expiration).isoformat(),
    }


def refresh_handler():
    api_credentials = get_api_credentials()
    return api_creds_to_cli_creds(api_credentials)


def create_clidriver(api_credentials: dict, args=None):
    debug = None
    if args is not None:
        parser = FirstPassGlobalArgParser()
        args, _ = parser.parse_known_args(args)
        debug = args.debug
    session = RefreshableSession(
        init_aws_creds=api_creds_to_cli_creds(api_credentials),
        refresh_handler=refresh_handler,
    )
    _set_user_agent_for_session(session)
    load_plugins(
        session.full_config.get("plugins", {}),
        event_hooks=session.get_component("event_emitter"),
    )
    error_handlers_chain = construct_cli_error_handlers_chain()
    driver = CLIDriver(session=session, error_handler=error_handlers_chain, debug=debug)
    return driver


# https://github.com/boto/boto3/issues/358#issuecomment-372086466
def run_aws_cli_command(cmd: list[str], api_credentials: dict):
    """Run a CLI command
    cmd: An array of cli args (e.g. ["s3", "ls"])
    credentials: A dictionary with credentials retrieved from
        the /aws-creds endpoint.
    """
    # Note: Don't add --debug flag even when flags["debug"] is True
    # because AWS CLI --debug prints sensitive tokens and credentials
    if flags.get("debug"):
        print(f'aws cli command: {" ".join(cmd)}')

    old_env = dict(os.environ)
    try:
        env = os.environ.copy()
        env["LC_CTYPE"] = "en_US.UTF"
        env["AWS_DEFAULT_REGION"] = api_credentials["region"]
        os.environ.update(env)

        # Run awscli in the same process
        driver = create_clidriver(api_credentials, cmd)

        try:
            exit_code = AWSCLIEntryPoint(driver=driver).main(cmd)

            if exit_code > 0:
                # Exit code indicates error but no exception was raised
                # The error was already printed to stderr by AWS CLI
                # We can't easily parse it after the fact, so provide generic guidance
                raise ExitError(
                    "AWS command failed.",
                    "Check the error message above for details about:",
                    "- Access denied: You may not have permission to this dataset",
                    "- No such access point: Dataset may have no files yet or ID is incorrect",
                    "- Expired credentials: Try running 'msdlive login' again",
                )
        except ExitError:
            # Re-raise our own ExitError as-is
            raise
        except Exception as e:
            # AWS CLI exceptions contain the error details
            error_msg = str(e).lower()

            # Parse specific error types from exception message
            if "accessdenied" in error_msg or "not authorized" in error_msg:
                raise ExitError(
                    "Access denied.",
                    "You don't have permission to access this dataset.",
                    "Verify you have the correct permissions or contact the dataset owner.",
                ) from e
            elif "nosuchaccesspoint" in error_msg:
                raise ExitError(
                    "Unable to access dataset storage.",
                    "This could mean the dataset has no files yet, the dataset ID is incorrect, or there's an access issue.",
                ) from e
            elif "expired" in error_msg or "invalid.*token" in error_msg:
                raise ExitError(
                    "Your session has expired.",
                    "Please run 'msdlive login' to authenticate again.",
                ) from e
            else:
                # Re-raise the original exception to preserve the full error message
                raise ExitError(
                    "Command failed.",
                    "See error output above for details.",
                ) from e
    finally:
        os.environ.clear()
        os.environ.update(old_env)
