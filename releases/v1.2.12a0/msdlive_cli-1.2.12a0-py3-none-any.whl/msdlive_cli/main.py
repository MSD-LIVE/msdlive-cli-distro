
import typer
from pathlib import Path

import sys
import platform
import sentry_sdk
import requests
from packaging.version import Version, InvalidVersion
from importlib.metadata import version
import logging


__version__ = version("msdlive-cli")

from .auth import login_user, logout_user
from .file_transfer import download_dataset, upload_dataset
from .file_list import list_files
from .flags import flags
from .ignore_file import IgnoreFile
from .errors import ExitError
from .config import help_url, environment_name


# Suppress Sentry's verbose logging
logging.getLogger("sentry_sdk").setLevel(logging.WARNING)

# Global variables for GitHub repository information
GITHUB_OWNER = "MSD-LIVE"
GITHUB_REPO = "msdlive-cli-distro"
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}"

sentry_sdk.init(
    dsn="https://dc234eb9eb6972cdbb0bf9e5c37020bd@o4503934099193856.ingest.sentry.io/4506259835191296",
    enable_tracing=True,
    environment=environment_name,
    debug=False,
)

# Suppress Sentry's "Waiting up to 2 seconds" message on shutdown
import atexit
import io
def suppress_sentry_output():
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        sentry_sdk.flush()
    finally:
        sys.stderr = old_stderr
atexit.register(suppress_sentry_output)

# Never dump local variables (e.g. passwords) in tracebacks
app = typer.Typer(rich_markup_mode="markdown", pretty_exceptions_show_locals=False)

def get_latest_github_version() -> str | None:
    """Return the latest version of msdlive-cli from GitHub releases."""
    try:
        url = f"{GITHUB_API_URL}/releases/latest"
        response = requests.get(url, timeout=3.0)
        if response.status_code != 200:
            return None
        data = response.json()
        latest = data.get("tag_name") or data.get("name")
        if latest:
            return latest.lstrip('v')
    except Exception as e:
        return None

def get_runtime_version() -> str:
    """Return the runtime version of the msdlive-cli package."""
    return __version__

def warn_new_version() -> None:
    current_cli_version = get_runtime_version()
    if current_cli_version == "unknown":
        return
    latest_cli_version = get_latest_github_version()
    if latest_cli_version is None:
        return
    try:
        if Version(latest_cli_version) > Version(current_cli_version):
            message = typer.style(
                f"A new version of msdlive-cli is available: v{latest_cli_version}. "
                f"You are currently using v{current_cli_version}.\n"
                f"Please visit {help_url} for more details.",
                fg=typer.colors.GREEN
            )
            typer.echo(message, err=True)
    except InvalidVersion:
        pass

def log_errors(fn):
    try:
        fn()
    except ExitError:
        # Expected user-facing error; message already printed
        raise
    except Exception as e:
        typer.echo(
                    f"Unexpected exception: "
                    f"{type(e).__module__}.{type(e).__qualname__}",
                    err=True,
                )
        try:
            sentry_sdk.capture_exception(e)
        except Exception:
            # Error reporting failing must not mask the original failure
            pass
        # Exit non-zero so scripts like `msdlive login && msdlive download ...`
        # don't treat a failure as success. Message is already printed above.
        raise ExitError(code=1) from e

def get_full_cmd_help(help):
    return f"{help}\n\n\n See {help_url} for more details."

@app.callback(help=get_full_cmd_help("MSD-LIVE's command line interface."))
def callback(debug: bool = False):
    flags["debug"] = debug
    # check for new version of msdlive-cli
    warn_new_version()


@app.command(help=get_full_cmd_help("Login to MSD-LIVE."))
def login(
    email: str = typer.Option(None, help="Email address"),
    password: str = typer.Option(None, help="Password"),
):
    # Prompt for missing credentials
    if email is None:
        # Need to prompt for email, so require TTY
        if not sys.stdin.isatty():
            is_windows = platform.system() == "Windows"
            messages = ["Login requires an interactive terminal when email is not provided"]
            if is_windows:
                messages.append("Use: winpty msdlive login")
            messages.append("Or provide credentials: msdlive login --email <email> --password <password>")
            raise ExitError(*messages)
        email = typer.prompt("Email")

    if password is None:
        # Need to prompt for password, so require TTY
        if not sys.stdin.isatty():
            is_windows = platform.system() == "Windows"
            messages = ["Login requires an interactive terminal when password is not provided"]
            if is_windows:
                messages.append("Use: winpty msdlive login")
            messages.append("Or provide credentials: msdlive login --email <email> --password <password>")
            raise ExitError(*messages)
        password = typer.prompt("Password", hide_input=True)

    log_errors(lambda: login_user(email=email, password=password))


@app.command(help=get_full_cmd_help("Logout of MSD-LIVE."))
def logout():
    log_errors(lambda: logout_user())


@app.command(help=get_full_cmd_help("Download files from a dataset or your scratch dir."))
def download(
    dataset_id: str = typer.Option(
        None, help="ID of the dataset (copied from the website's CLI instructions)"
    ),
    scratch: bool = typer.Option(
        False, help="Download scratch files instead of specifying a dataset ID"
    ),
    output_dir: Path = typer.Option(..., help="Local directory to save the files"),
    quiet: bool = typer.Option(
        False,
        help="Hide output during download",
    ),
    filter_file: Path = typer.Option(
        None,
        help=f"YAML configuration file used to download a subset of files",
    ),
):
    if not dataset_id and not scratch:
        raise typer.BadParameter("You must provide either --dataset-id or --scratch.")
    download_dataset(
        dataset_id=dataset_id,
        dst_dir=output_dir,
        ignore_file=IgnoreFile.parse_cli_option(filter_file),
        quiet=quiet,
        scratch=scratch,
    )


@app.command(help=get_full_cmd_help("Upload files to a dataset."))
def upload(
    src_dir: Path = typer.Option(..., help="Local directory containing the files"),
    dataset_id: str = typer.Option(
        ..., help="ID of the dataset (copied from the website's CLI instructions)"
    ),
    quiet: bool = typer.Option(False, help="Hide output during upload"),
    delete: bool = typer.Option(
        False, help="Delete files in MSD-LIVE that do not exist in src_dir"
    ),
    filter_file: Path = typer.Option(
        None,
        help=f"YAML configuration file used to upload a subset of files",
    ),
):
    upload_dataset(
        src_dir=src_dir,
        dataset_id=dataset_id,
        delete=delete,
        quiet=quiet,
        ignore_file=IgnoreFile.parse_cli_option(filter_file),
    )


@app.command(help=get_full_cmd_help("List dataset or scratch dir files."))
def list(
    dataset_id: str = typer.Option(
        None, help="ID of the dataset"
    ),
    scratch: bool = typer.Option(
        False, help="List my scratch dir instead of a dataset's"
    ),
):
    if not dataset_id and not scratch:
        raise typer.BadParameter("You must provide either --dataset-id or --scratch.")
    list_files(
        dataset_id=dataset_id,
        scratch=scratch,
    )

@app.command(name="version", help=get_full_cmd_help("Show the currently installed msdlive-cli version."))
def get_version_cmd():
    typer.echo(get_runtime_version())
