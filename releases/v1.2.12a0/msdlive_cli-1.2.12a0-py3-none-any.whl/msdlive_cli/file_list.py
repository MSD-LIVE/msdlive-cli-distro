import typer
from rich import print
from rich.progress import Progress, SpinnerColumn, TextColumn
from typing import Optional
import sys

from .auth import get_api_credentials, should_reauthenticate, ReAuthReason, login_user
from .aws_cli_connection import run_aws_cli_command
from .ignore_file import IgnoreFile
from .lib import get_access_point_arn

def list_files(
    dataset_id: str,
    scratch: bool = False,
):
    auth_required, reason = should_reauthenticate()
    if auth_required:
        if reason is ReAuthReason.NEVER_LOGGED_IN:
            print("You must log in to access data.")
        elif reason is ReAuthReason.SESSION_EXPIRED:
            print("Your session has expired.")
        login_user()

    api_credentials = get_api_credentials()
    email = api_credentials.get("email")
    access_point_arn = get_access_point_arn(
        dataset_id=dataset_id,
        region=api_credentials["region"],
        account_id=api_credentials["accountId"],
        scratch=scratch,
        email=email,
    )

    if scratch:
        s3_path = f"{email}/"
    else:
        s3_path = f"{dataset_id}/"

    cmd = ["s3", "ls", f"{access_point_arn}/{s3_path}", "--recursive", "--summarize", "--human-readable"]
    task_description = f"Listing {s3_path} dir..."

    # Only use Progress bar if stdout is connected to a terminal
    # (Progress bar writes to stdout, so we check stdout not stdin)
    has_tty = sys.stdout.isatty()
    if has_tty:
        # Use context manager to ensure cleanup on error
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
            ) as progress:
                progress.add_task(description=task_description, total=None)
                run_aws_cli_command(
                    cmd=cmd,
                    api_credentials=api_credentials,
                )
        except Exception:
            # Progress bar will be cleaned up by context manager
            raise
    else:
        # Non-TTY: just output plain text for scripts/Docker/automation
        typer.echo(task_description)
        run_aws_cli_command(
            cmd=cmd,
            api_credentials=api_credentials,
        )

    # Note: AWS CLI s3 ls with --summarize will show "Total Objects: 0" for empty datasets
    # The user will see this in the output. If no output appears at all, dataset may not exist.
