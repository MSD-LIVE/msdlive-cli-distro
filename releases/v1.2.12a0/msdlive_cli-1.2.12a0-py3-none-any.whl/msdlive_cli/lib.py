from pathlib import Path

import typer
import requests
import re

from .config import environment_name
from .flags import flags
from .errors import ExitError


def get_app_path() -> Path:
    app_name = f"msdlive-cli-{environment_name}"
    app_path: Path = Path(typer.get_app_dir(app_name))
    permissions = 0o700
    app_path.mkdir(mode=permissions, parents=True, exist_ok=True)
    # In case the directory already existed, make sure it has the right permissions
    app_path.chmod(permissions)
    return app_path


def _get_error_message(response: requests.Response):
    """Best-effort extraction of an error message from an error response.

    Error bodies are not guaranteed to be JSON, nor to use the "message" key:
    - CloudFront serves HTML error pages for its own 4xx/5xx responses
    - Lambda Function URL and API Gateway service errors (403 AccessDenied,
      429 Rate Exceeded) use "Message" with a capital M

    Returns None when no usable message can be found.
    """
    try:
        error_body = response.json()
    except ValueError:
        # Non-JSON body, e.g. an HTML error page
        return None
    if not isinstance(error_body, dict):
        return None
    # Our API uses "message"; AWS service errors use "Message"
    return error_body.get("message") or error_body.get("Message")


def handle_request_errors(
    response: requests.Response,
):
    messages = ["Request failed"]
    if response.status_code < 400:
        # There isn't an error
        # but check if response is valid json
        try:
            response.json()
        except:
            messages.append("Invalid json response")
            if flags["debug"]:
                messages.append(response.text)
        else:
            return
    if response.status_code >= 400 and response.status_code < 500:
        error_message = _get_error_message(response)
        if error_message and "Token expired" in error_message:
            if flags["debug"]:
                messages.append(error_message)
            messages.append(
                "Your authentication token expired, run the msdlive login command"
            )
        elif error_message:
            messages.append(error_message)
        else:
            # No usable message: non-JSON body, or JSON without a message key
            messages.append(f"The server returned an error (HTTP {response.status_code})")
            if flags["debug"]:
                messages.append(response.text)
    if response.status_code >= 500:
        messages.append("Unexpected error")
        messages.append("Please email info@msdlive.org if this error persists")
        if flags["debug"]:
            # Use .text, not .json(): 5xx bodies are often HTML
            messages.append(response.text)
    raise ExitError(*messages)


def _email_to_access_point(email: str) -> str:
    # Convert to lowercase and replace invalid characters with hyphens
    email = email.lower()
    email = re.sub(
        r"[^a-z0-9-]", "-", email
    )  # Keep only lowercase letters, numbers, and hyphens

    # add dev as prefix if not prod
    email = (
        email
        if environment_name == "prod"
        else f"{environment_name}-{email}"
    )

    # Ensure the access point name doesn't start or end with a hyphen
    email = email.strip("-")

    # Truncate to 50 characters and avoid ending with '-s3alias'
    email = email[:50]
    if email.endswith("-s3alias"):
        email = email[:-8]

    # Handle potential trailing hyphen after truncation
    email = email.rstrip("-")

    # Ensure minimum length of 3 characters
    if len(email) < 3:
        email = (email + "abc")[:3]

    return email

def get_access_point_arn(dataset_id: str, region: str, account_id: str, scratch: bool, email: str):
    if scratch:
        # access point arns for scratch dirs are named using
        # hard coding for now to test
        # access_point_name = f"dev-admin-msdlive-org"
        access_point_name = _email_to_access_point(email)
    else:
        access_point_name = dataset_id
    return f"arn:aws:s3:{region}:{account_id}:accesspoint/{access_point_name}"
