"""MSD-LIVE CLI package."""

__version__ = "1.2.6"
