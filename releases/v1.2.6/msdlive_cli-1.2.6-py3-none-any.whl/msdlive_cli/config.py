environment_name = "dev"
auth_url = "https://iozv0n74a6.execute-api.us-west-2.amazonaws.com/prod"
help_url = "https://dev.msdlive.org/cli-help"
