# MSD-LIVE CLI

A CLI for managing [MSD-LIVE](https://msdlive.org) data.

## Install

To install this CLI, copy the command from the [CLI help page](https://msdlive.org/sb/cli-help). Each development tier (i.e. dev, stage, and prod) has a CLI help page, and the install command on each is specific to that tier.

## Usage

Run `msdlive --help` to see usage information.
